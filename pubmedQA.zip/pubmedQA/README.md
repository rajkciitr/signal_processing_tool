---
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
  - split: valid
    path: data/valid-*
  - split: test
    path: data/test-*
dataset_info:
  features:
  - name: id
    dtype: string
  - name: query
    dtype: string
  - name: answer
    dtype: string
  - name: choices
    sequence: string
  - name: gold
    dtype: int64
  splits:
  - name: train
    num_bytes: 81909
    num_examples: 50
  - name: valid
    num_bytes: 81909
    num_examples: 50
  - name: test
    num_bytes: 834914
    num_examples: 500
  download_size: 529693
  dataset_size: 998732
---
# Dataset Card for "pubmedqa_test"

[More Information needed](https://github.com/huggingface/datasets/blob/main/CONTRIBUTING.md#how-to-contribute-to-the-dataset-cards)