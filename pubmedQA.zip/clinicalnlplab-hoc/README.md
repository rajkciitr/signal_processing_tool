---
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
  - split: valid
    path: data/valid-*
  - split: test
    path: data/test-*
dataset_info:
  features:
  - name: id
    dtype: string
  - name: query
    dtype: string
  - name: answer
    dtype: string
  - name: choices
    sequence: string
  - name: gold
    sequence: int64
  splits:
  - name: train
    num_bytes: 3062367
    num_examples: 1108
  - name: valid
    num_bytes: 430760
    num_examples: 157
  - name: test
    num_bytes: 863678
    num_examples: 315
  download_size: 1496963
  dataset_size: 4356805
---
# Dataset Card for "HoC_test"

[More Information needed](https://github.com/huggingface/datasets/blob/main/CONTRIBUTING.md#how-to-contribute-to-the-dataset-cards)