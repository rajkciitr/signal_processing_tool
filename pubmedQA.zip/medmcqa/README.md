---
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
  - split: valid
    path: data/valid-*
  - split: test
    path: data/test-*
dataset_info:
  features:
  - name: id
    dtype: string
  - name: query
    dtype: string
  - name: answer
    dtype: string
  - name: choices
    sequence: string
  - name: gold
    dtype: int64
  splits:
  - name: train
    num_bytes: 2873180
    num_examples: 4183
  - name: valid
    num_bytes: 2873180
    num_examples: 4183
  - name: test
    num_bytes: 2873180
    num_examples: 4183
  download_size: 2161257
  dataset_size: 8619540
---
# Dataset Card for "medMCQA_test"

[More Information needed](https://github.com/huggingface/datasets/blob/main/CONTRIBUTING.md#how-to-contribute-to-the-dataset-cards)