package com.example.sensordisplay

import android.hardware.Sensor
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.SensorEvent

class SensorCollector(private val sensorManager: SensorManager):
    SensorEventListener {

    @Volatile
    var acc: FloatArray= FloatArray(3)
    @Volatile
    var gra:FloatArray= FloatArray(3)
    @Volatile
    var gyro:FloatArray= FloatArray(3)
    @Volatile
    var mag:FloatArray= FloatArray(3)
    @Volatile
    var steps:Float= 0f

    private val samplingUs = 16_000

    fun register(): Boolean{
        val a = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?:return false
        val g = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)?:return false
        val y = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?:return false
        val m = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)?:return false
        val s = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)?:return false

        sensorManager.registerListener(this, a, samplingUs)
        sensorManager.registerListener(this, g, samplingUs)
        sensorManager.registerListener(this, y, samplingUs)
        sensorManager.registerListener(this, m, samplingUs)
        sensorManager.registerListener(this, s, SensorManager.SENSOR_DELAY_NORMAL)

        return true
    }


    fun unregister() {
        sensorManager.unregisterListener(this)
    }

   override fun onSensorChanged(event: SensorEvent)
        {
            if(event==null) return
            when(event.sensor.type)
            {
                Sensor.TYPE_ACCELEROMETER->acc=event.values.clone()
                Sensor.TYPE_GRAVITY->gra=event.values.clone()
                Sensor.TYPE_GYROSCOPE->gyro=event.values.clone()
                Sensor.TYPE_MAGNETIC_FIELD->mag=event.values.clone()
                Sensor.TYPE_STEP_COUNTER->steps=event.values[0]
            }
        }



    override fun onAccuracyChanged(
        sensor: Sensor?,
        accuracy: Int
    ) = Unit


}