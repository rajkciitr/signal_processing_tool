package com.example.sensordisplay

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread
import kotlin.math.log10
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var dbText: TextView

    private var isRecording = false

    private val sampleRate = 16000
    private val recordingSeconds = 1

    private lateinit var sensorManager: SensorManager
    private lateinit var sensorCollector: SensorCollector

    private lateinit var acx: TextView
    private lateinit var acy: TextView
    private lateinit var acz: TextView

    private val handler = Handler()
    private var logSense = false

    private val updateTask = object : Runnable {
        override fun run() {

            if (logSense) {

                val acc = sensorCollector.acc

                acx.text = acc[0].toString()
                acy.text = acc[1].toString()
                acz.text = acc[2].toString()

                handler.postDelayed(this, 100)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        dbText = findViewById(R.id.dbText)

        checkPermissionAndStart()

        sensorManager =
            getSystemService(Context.SENSOR_SERVICE) as SensorManager

        sensorCollector = SensorCollector(sensorManager)

        acx = findViewById(R.id.acx)
        acy = findViewById(R.id.acy)
        acz = findViewById(R.id.acz)

        val start = findViewById<Button>(R.id.btStart)
        val stop = findViewById<Button>(R.id.btStop)

        start.setOnClickListener {

            logSense = true
            sensorCollector.register()
            handler.post(updateTask)
        }

        stop.setOnClickListener {

            logSense = false
            sensorCollector.unregister()
        }
    }

    private fun checkPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                100
            )

        } else {
            startRecording()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )

        if (requestCode == 100 &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            startRecording()
        }
    }

    private fun startRecording() {

        val bufferSize = sampleRate * recordingSeconds

        val audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize * 2
        )

        val audioBuffer = ShortArray(bufferSize)

        isRecording = true

        audioRecord.startRecording()

        thread(start = true) {

            while (isRecording) {

                val readSize = audioRecord.read(
                    audioBuffer,
                    0,
                    audioBuffer.size
                )

                if (readSize > 0) {

                    // Compute RMS
                    var sum = 0.0

                    for (i in 0 until readSize) {
                        sum += (audioBuffer[i] * audioBuffer[i]).toDouble()
                    }

                    val rms = sqrt(sum / readSize)

                    // Convert RMS to dB
                    val db = 20 * log10(rms)

                    runOnUiThread {
                        dbText.text = String.format("%.2f dB", db)
                    }
                }
            }

            audioRecord.stop()
            audioRecord.release()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRecording = false
    }

    override fun onPause() {
        super.onPause()

        sensorCollector.unregister()
        handler.removeCallbacks(updateTask)
    }
}